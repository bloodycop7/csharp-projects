﻿namespace FootballTeam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double tshirtPrice = double.Parse(Console.ReadLine());
            
            if ( tshirtPrice < 1.00 || tshirtPrice > 1000.00 )
            {
                Console.WriteLine("T-Shirt Price must be between 0.00 and 10 00.00");

                return;
            }

            double requiredPrice = double.Parse(Console.ReadLine());

            if ( requiredPrice < 1.00 || requiredPrice > 10000.00 )
            {
                Console.WriteLine("Required Price must be between 100.00 and 10 000.00");

                return;
            }

            double shortsPrice = tshirtPrice * 0.75;
            double socksPrice = shortsPrice * 0.20;
            double kickersPrice = (tshirtPrice + shortsPrice) * 2;

            double totalPrice = tshirtPrice + shortsPrice + socksPrice + kickersPrice;

            totalPrice = totalPrice - ( totalPrice * 0.15 );

            /*
                string debugString = $"[DEBUGGING]";
                debugString = debugString + $"\n[New Total Price] : {totalPrice}";
                debugString = debugString + $"\n[Old Total Price] : {oldPrice}";
                debugString = debugString + $"\n[T-Shirt Price] : {tshirtPrice}";
                debugString = debugString + $"\n[Shorts Price] : {shortsPrice}";
                debugString = debugString + $"\n[Socks Price] : {socksPrice}";
                debugString = debugString + $"\n[Kickers Price] : {kickersPrice}";

                Console.WriteLine(debugString);
            */

            string output = "Yes, he will earn the world-cup replica ball!";
            output = output + $"\nHis sum is {Math.Round(totalPrice, 2)}";

            if ( totalPrice < requiredPrice )
            {
                output = "No, he will not earn the world-cup replica ball.";
                output = output + $"\nHe needs {-Math.Round(totalPrice - requiredPrice, 2)} lv. more.";
            }

            Console.WriteLine(output);
        }
    }
}
