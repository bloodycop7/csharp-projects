﻿namespace FoodMarket
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double strawberryPrice = double.Parse(Console.ReadLine());
            double bananasCount = double.Parse(Console.ReadLine());
            double orangesCount = double.Parse(Console.ReadLine());
            double raspBerryCount = double.Parse(Console.ReadLine());
            double strawberryCount = double.Parse(Console.ReadLine());

            double raspberryPrice = strawberryPrice / 2;
            double orangePrice = raspberryPrice - (0.4 * raspberryPrice);
            double bananaPrice = raspberryPrice - (0.8 * raspberryPrice);

            double strawBerrySum = strawberryCount * strawberryPrice;
            double orangesSum = orangesCount * orangePrice;
            double raspBerriesSum = raspBerryCount * raspberryPrice;
            double bananasSum = bananasCount * bananaPrice;

            if ( strawberryPrice < 0.00 || strawberryPrice > 10000.00 )
            {
                Console.WriteLine("Strawberry Price must be between 0.00 and 10000.00");

                return;
            }

            if ( bananasCount < 0.00 || bananasCount > 10000.00 )
            {
                Console.WriteLine("Bananas Count must be between 0.00 and 10000.00");

                return;
            }

            if ( orangesCount < 0.00 || orangesCount > 10000.00 )
            {
                Console.WriteLine("Oranges Count must be between 0.00 and 10000.00");

                return;
            }

            if ( raspBerryCount < 0.00 || raspBerryCount > 10000.00 )
            {
                Console.WriteLine("Raspberries must be between 0.00 and 10000.00");

                return;
            }

            if ( strawberryCount < 0.00 || strawberryCount > 10000.00 )
            {
                Console.WriteLine("Strawberries Count must be between 0.00 and 10000.00");

                return;
            }

            Console.WriteLine($"Total Price: {(Math.Round(raspBerriesSum + orangesSum + bananasSum + strawBerrySum, 2))}.");
        }
    }
}
