﻿namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write your name: ");
            var name = Console.ReadLine();
            Console.WriteLine("Hello, I'm {0}!", name);
        }
    }
}