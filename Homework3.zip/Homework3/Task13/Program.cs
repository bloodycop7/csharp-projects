﻿namespace Task13
{
    internal class Program
    {
        // Напишете програма, която изисква потребителят да въведе текст и след това извежда броя на символите в текста.
        static void Main(string[] args)
        {
            /*
            Console.Write("Input text: ");
            string input = Console.ReadLine();
            bool hasSymbols = false;
            int symbolCount = 0;

            string symbols = @"\|!#$%&/()=?»«@£§€{}-;'<>_";

            foreach (var item in input.ToCharArray())
            {
                if ( item.Contains(symbols))
                {
                    hasSymbols = true;
                    symbolCount++;
                }
            }

            if ( hasSymbols )
            {
                if ( symbolCount == 1)
                {
                    Console.WriteLine("There is {0} symbol in your message.", symbolCount);
                }
                else
                {
                    Console.WriteLine("There are {0} symbols in your message.", symbolCount);
                }
            }
            */ // Някой друг ден :D
        }
    }
}