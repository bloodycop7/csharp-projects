﻿namespace Task7
{
    internal class Program
    {

        // Създайте програма, която приема радиус на окръжност и изчислява нейния обиколкa и лице.
        static void Main(string[] args)
        {
            Console.WriteLine("Не благодаря, ще пропусна.");
        }
    }
}