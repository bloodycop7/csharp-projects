﻿namespace Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (char letter = 'a'; letter <= 'z'; letter++)
            {
                Console.WriteLine(letter);
            }
        }
    }
}
