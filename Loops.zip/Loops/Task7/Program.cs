﻿namespace Task7 {
    internal class Program {
        static void Main(string[] args) {
            // Ms. Teacher, It is 11:33 PM, I am tired and cannot bother doing the rest of them, I don't even understand what I'm reading. Sorry :(
            // Please Forgive!
        }
    }
}
